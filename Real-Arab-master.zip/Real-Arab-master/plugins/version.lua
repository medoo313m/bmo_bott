--[[
▀▄ ▄▀▀▄▄▀▀▄▄▀▀▄▄▀▀▄▄▀▀▄▄▀▀▄▄▀▀▄▀▄▄▀▀▄▄▀▀▄▄▀▀▄▄▀▀          
▀▄ ▄▀                                      ▀▄ ▄▀ 
▀▄ ▄▀    BY OmarReal                       ▀▄ ▄▀ 
▀▄ ▄▀     BY OmarReal (Omar_Real7)         ▀▄ ▄▀ 
▀▄ ▄▀ JUST WRITED BY OmarReal              ▀▄ ▄▀   
▀▄ ▄▀                                      ▀▄ ▄▀ 
▀▄▀▀▄▄▀▀▄▄▀▄▄▀▀▄▄▀▀▄▄▀▄▄▀▀▄▄▀▀▄▄▀▄▄▀▀▄▄▀▀▄▄▀▄▄▀▀
--]]

do

function run(msg, matches)
  return 'سورس 🛢 Real-Arabic 📁\nالنسخة 📋 v1.2\n الموقع 💻\n \nhttps://github.com/Arabic-Bot/Real-Arab.git \n  المطورين 🕵🔧 : \n @Omar_Real \n @Mohammedzedan\n @ALNAZEXR \n @X_A_A'
end

return {
  patterns = {
    "^ArabicReal"
  }, 
  run = run 
}

end
