# Arabic-Real

# developers المطورين

@Omar_Real

@Mohammedzedan 

@ALNAZEXR

@X_A_A


# التنصيب

```sh
# Install dependencies.
# Tested on Ubuntu 14.04. For other OSs, check out https://github.com/yagop/telegram-bot/wiki/Installation
sudo apt-get install libreadline-dev libconfig-dev libssl-dev lua5.2 liblua5.2-dev lua-socket lua-sec lua-expat libevent-dev make unzip git redis-server autoconf g++ libjansson-dev libpython-dev expat libexpat1-dev

# Let's install the bot.
cd $HOME
git clone https://github.com/Arabic-Bot/Real-Arab.git -b supergroups
cd TeleSeed
chmod +x launch.sh
./launch.sh install
./launch.sh # Enter a phone number & confirmation code.
```
### One command
 على السيرفر VPS
```sh
#https://github.com/yagop/telegram-bot/wiki/Installation
sudo apt-get update; sudo apt-get upgrade -y --force-yes; sudo apt-get dist-upgrade -y --force-yes; sudo apt-get install libreadline-dev libconfig-dev libssl-dev lua5.2 liblua5.2-dev lua-socket lua-sec lua-expat libevent-dev libjansson* libpython-dev make unzip git redis-server g++ autoconf -y --force-yes && git clone https://github.com/Arabic-Bot/Real-Arab.git -b supergroups && cd TeleSeed && chmod +x launch.sh && ./launch.sh install && ./launch.sh
```

* * *

### Realm configuration

طريقة جعل نفسك المطوور الوحيد في البوت

افتح مجلد ال DETA وقم بوضع الايدي الخاص بك
```
  sudo_users = {
    110626080,
    103649648,
    111020322,
    0,
    YourID
  }
```

# نتمنى لكم تنصيب ممتع :)

# القنوات الخاصة

@linuxch

@iq_dev8
